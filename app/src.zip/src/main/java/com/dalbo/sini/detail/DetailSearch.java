package com.dalbo.sini.detail;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.dalbo.sini.DetailActivity;

/**
 * Created by alkaaf on 5/22/2016.
 */
public class DetailSearch extends DetailActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
