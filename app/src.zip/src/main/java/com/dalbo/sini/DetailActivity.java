package com.dalbo.sini;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.dalbo.sini.db.service;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by alkaaf on 5/22/2016.
 */
public class DetailActivity extends Activity implements View.OnClickListener{
    TextView det_id, det_tglpost, det_barang, det_deskripsi, det_nama, det_telp, det_status, det_tgl;
    Button bopenmap, changestatus;
    String slat, slng;
    String status;
    int id;
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail);
        i = getIntent();
        det_id = (TextView)findViewById(R.id.det_id);
        det_tglpost = (TextView)findViewById(R.id.det_tglpost);
        det_barang = (TextView)findViewById(R.id.det_barang);
        det_deskripsi = (TextView)findViewById(R.id.det_desk);
        det_nama = (TextView)findViewById(R.id.det_atasnama);
        det_telp = (TextView)findViewById(R.id.det_telp);
        det_status = (TextView)findViewById(R.id.det_status);
        det_tgl = (TextView)findViewById(R.id.det_tgl);
        bopenmap = (Button)findViewById(R.id.openmap);
        changestatus = (Button)findViewById(R.id.changestatus);
        bopenmap.setOnClickListener(this);
        det_telp.setOnClickListener(this);
        changestatus.setOnClickListener(this);

        String stat = null;
        id = Integer.parseInt(i.getExtras().getString("id"));
        det_id.setText("ID: "+i.getExtras().getString("id"));
        det_tglpost.setText(new SimpleDateFormat("MM/dd/yyyy").format(new Date(Long.parseLong(i.getExtras().getString("timestamp"))*1000)));
        det_barang.setText(i.getExtras().getString("barang"));
        det_deskripsi.setText(i.getExtras().getString("deskripsi"));
        det_nama.setText(i.getExtras().getString("nama"));
        det_telp.setText(i.getExtras().getString("telp"));
        status = i.getExtras().getString("status");
        if(status.equalsIgnoreCase("1")){
            det_status.setText("Ditemukan");
            changestatus.setText("Sudah dikembalikan");
        }
        else if(status.equalsIgnoreCase("2")){
            det_status.setText("Hilang");
            changestatus.setText("Sudah ditemukan");
        }
        else if(status.equalsIgnoreCase("3")){
            det_status.setText("Terselesaikan");
            changestatus.setEnabled(false);
        }

        det_tgl.setText(i.getExtras().getString("tanggal"));
        slat = i.getExtras().getString("lat");
        slng = i.getExtras().getString("lng");
    }

    @Override
    public void onClick(View v) {
        if(v == bopenmap) {
            Intent i = new Intent(this, MapsActivity.class);
            i.putExtra("lat", slat);
            i.putExtra("lng", slng);
            i.putExtra("nama", i.getExtras().getString("nama"));
            i.putExtra("alamat", i.getExtras().getString("alamat"));
            i.putExtra("telp",i.getExtras().getString("telp"));
            i.putExtra("status",i.getExtras().getString("status"));
            startActivity(i);
        }
        else if (v == det_telp){
            String phone = det_telp.getText().toString();
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
            startActivity(i);
        }
        else if(v == changestatus){
            service s = new service(getString(R.string.webservice_address),this,this);
            s.changestatus(id,3);
        }
    }
}