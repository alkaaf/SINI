package com.dalbo.sini.detail;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.dalbo.sini.DetailActivity;
import com.dalbo.sini.R;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by alkaaf on 5/20/2016.
 */
public class DetailIlang extends DetailActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
